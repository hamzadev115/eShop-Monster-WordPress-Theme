<?php

/**
 * eShop Monster functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package eShop_Monster
 */

if (!defined('_S_VERSION')) {
	// Replace the version number of the theme on each release.
	define('_S_VERSION', '1.0.0');
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function eshop_monster_setup()
{
	/*
		* Make theme available for translation.
		* Translations can be filed in the /languages/ directory.
		* If you're building a theme based on eShop Monster, use a find and replace
		* to change 'eshop-monster' to the name of your theme in all the template files.
		*/
	load_theme_textdomain('eshop-monster', get_template_directory() . '/languages');

	// Add default posts and comments RSS feed links to head.
	add_theme_support('automatic-feed-links');

	/*
		* Let WordPress manage the document title.
		* By adding theme support, we declare that this theme does not use a
		* hard-coded <title> tag in the document head, and expect WordPress to
		* provide it for us.
		*/
	add_theme_support('title-tag');

	/*
		* Enable support for Post Thumbnails on posts and pages.
		*
		* @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		*/
	add_theme_support('post-thumbnails');

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus(
		array(
			'top-menu' => esc_html__('Top Menu', 'eshop-monster'),
			'mega-menu-1' => esc_html__('Mega Menu Colum 1', 'eshop-monster'),
			'mega-menu-2' => esc_html__('Mega Menu Colum 2', 'eshop-monster'),
			'mega-menu-3' => esc_html__('Mega Menu Colum 3', 'eshop-monster'),
			'mega-menu-4' => esc_html__('Mega Menu Colum 4', 'eshop-monster'),
			'footer-menu' => esc_html__('Footer Menu', 'eshop-monster'),
		)
	);

	/*
		* Switch default core markup for search form, comment form, and comments
		* to output valid HTML5.
		*/
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);

	// Set up the WordPress core custom background feature.
	add_theme_support(
		'custom-background',
		apply_filters(
			'eshop_monster_custom_background_args',
			array(
				'default-color' => 'ffffff',
				'default-image' => '',
			)
		)
	);

	// Add theme support for selective refresh for widgets.
	add_theme_support('customize-selective-refresh-widgets');

	/**
	 * Add support for core custom logo.
	 *
	 * @link https://codex.wordpress.org/Theme_Logo
	 */
	add_theme_support(
		'custom-logo',
		array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		)
	);
}
add_action('after_setup_theme', 'eshop_monster_setup');

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function eshop_monster_content_width()
{
	$GLOBALS['content_width'] = apply_filters('eshop_monster_content_width', 640);
}
add_action('after_setup_theme', 'eshop_monster_content_width', 0);

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function eshop_monster_widgets_init()
{
	register_sidebar(
		array(
			'name'          => esc_html__('Sidebar', 'eshop-monster'),
			'id'            => 'sidebar-1',
			'description'   => esc_html__('Add widgets here.', 'eshop-monster'),
			'before_widget' => '<section id="%1$s" class="widget %2$s">',
			'after_widget'  => '</section>',
			'before_title'  => '<h2 class="widget-title">',
			'after_title'   => '</h2>',
		)
	);
}
add_action('widgets_init', 'eshop_monster_widgets_init');

/**
 * Enqueue scripts and styles.
 */

/**
 * Custom Post Types & Meta Boxes
 */
require get_template_directory() . '/inc/post-types/category-slider.php';
require get_template_directory() . '/inc/post-types/meta.php';
require get_template_directory() . '/inc/post-types/brand-slider.php';
require get_template_directory() . '/inc/post-types/brand-meta.php';

require get_template_directory() . '/inc/scripts.php';
/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';
require get_template_directory() . '/inc/class-tgm-plugin-activation.php';
require get_template_directory() . '/inc/plugins.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if (defined('JETPACK__VERSION')) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Load WooCommerce compatibility file.
 */
if (class_exists('WooCommerce')) {
	require get_template_directory() . '/inc/woocommerce.php';
}
function ocdi_import_files()
{
	return array(
		array(
			'import_file_name'             => 'Demo Import 1',
			'categories'                   => array('Category 1', 'Category 2'),
			'local_import_file'            => trailingslashit(get_template_directory()) . 'demo/default/content.xml',
			'local_import_widget_file'     => trailingslashit(get_template_directory()) . 'demo/default/widgets.json',
			'local_import_customizer_file' => trailingslashit(get_template_directory()) . 'demo/default/customizer.dat',
			'import_preview_image_url'     => get_template_directory() . 'demo/default/img.png',
			'import_notice'                => __('After you import this demo, you will have to setup the slider separately.', 'eshop-monster'),
			'preview_url'                  => 'http://localhost/eshop/checkout/',
		),
	);
}
add_filter('ocdi/import_files', 'ocdi_import_files');
