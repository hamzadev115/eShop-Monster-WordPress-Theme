function mega_menu(){
  let menubtn = document.querySelector('.hum');
    let menu = document.querySelector('.menu-list');

    menubtn.addEventListener("click", function () {
      if (menu.style.display === "none" || menu.style.display === "") {
          menu.style.display = "block";
          menubtn.querySelector('i').classList.remove('fa-bars');
          menubtn.querySelector('i').classList.add('fa-chevron-up'); // Change to your desired arrow icon
      } else {
          menu.style.display = "none";
          menubtn.querySelector('i').classList.remove('fa-chevron-up');
          menubtn.querySelector('i').classList.add('fa-bars');
      }
    });
}

mega_menu();

function category_caresoul() { 
  jQuery(document).ready(function(){
    jQuery(".category-slider").owlCarousel({
      items:1,
      loop:true,
      autoplay:true,
      autoplayTimeout:5000,
      autoplayHoverPause:true,
      dots:false,
      nav:true,
      navText:[
        '<i class="fa fa-chevron-left"></i>' , '<i class="fa fa-chevron-right"></i>'
      ]
    });
  });
}
category_caresoul();

