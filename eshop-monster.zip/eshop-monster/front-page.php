<?php

/**
 * The template for displaying front page
 *
 * This is the template that displays front page by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package eShop_Monster
 */

get_header();
?>
<div class="container hero my-5">
	<div class="row">
		<div class="col-12 col-md-6 hero-left">
			<h2><?php echo get_theme_mod('hero_heading', esc_html__('Imagine the Fashion Adventures.', 'kirki')) ?></h2>
			<p><?php echo get_theme_mod('hero_para', esc_html__('Embark on a sartorial odyssey through time and style, exploring the evolution of fashion across cultures, trends, and innovations in The Fashion Adventures', 'kirki')) ?></p>
			<div class="hero-left-btn">
				<div class="men"> <a href="<?php echo esc_url(get_theme_mod('button_1_url', 'http://localhost/eshop/index.php/product-category/men/')) ?>"><?php echo get_theme_mod('hero_button_1', esc_html__('Men', 'kirki')) ?> <i class="fa-solid fa-arrow-right-long"></i></a></div>
				<div class="women"> <a href="<?php echo esc_url(get_theme_mod('button_2_url', 'http://localhost/eshop/index.php/product-category/women/')) ?>"><?php echo get_theme_mod('hero_button_2', esc_html__('Women', 'kirki')) ?> <i class="fa-solid fa-arrow-right-long"></i></a></div>
				<div class="kid"> <a href="<?php echo esc_url(get_theme_mod('button_3_url', 'http://localhost/eshop/index.php/product-category/kids/')) ?>"><?php echo get_theme_mod('hero_button_3', esc_html__('Kids', 'kirki')) ?> <i class="fa-solid fa-arrow-right-long"></i></a></div>
			</div>
		</div>
		<div class="row col-12 col-md-6 justify-content-end hero-right">
			<div class="background-img" style="background-image: url('<?php echo esc_url(get_theme_mod('bg-image_setting_url', 'DEFAULT_BACKGROUND_IMAGE_URL')); ?>');">
			</div>
			<img class="overlay-image" src="<?php echo esc_url(get_theme_mod('image_setting_url', 'DEFAULT_OVERLAY_IMAGE_URL')); ?>" alt="" srcset="">
		</div>
	</div>
</div>

<?php if (true == get_theme_mod('switch_setting', 'on')) : ?>
	<div class="container why-choose-us">

		<div class="row">
			<div class="col-12 col-md-6 col-lg-3 global">
				<img src="<?php echo esc_url(get_theme_mod('global', '')); ?>" alt="">
				<div class="icon-details">
					<h2><?php echo esc_html(get_theme_mod('global_heading', 'Global Shipping')); ?></h2>
					<p><?php echo esc_html(get_theme_mod('global_para', 'Shop from anywhere in the world. We ship worldwide.')); ?></p>
				</div>

			</div>
			<div class="col-12 col-md-6 col-lg-3 global">
				<img src="<?php echo esc_url(get_theme_mod('safe', '')); ?>" alt="">
				<div class="icon-details">
					<h2><?php echo esc_html(get_theme_mod('safe_heading', 'Safe Checkout')); ?></h2>
					<p><?php echo esc_html(get_theme_mod('safe_para', 'We protect our customer data at any cost')); ?></p>
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 global">
				<img src="<?php echo esc_url(get_theme_mod('easy', '')); ?>" alt="">
				<div class="icon-details">
					<h2><?php echo esc_html(get_theme_mod('easy_heading', 'Easy Returns')); ?></h2>
					<p><?php echo esc_html(get_theme_mod('easy_para', 'We have a free return& exchange policy.')); ?></p>
				</div>
			</div>
			<div class="col-12 col-md-6 col-lg-3 global">
				<img src="<?php echo esc_url(get_theme_mod('help', '')); ?>" alt="">
				<div class="icon-details">
					<h2><?php echo esc_html(get_theme_mod('help_heading', 'Help & Support')); ?></h2>
					<p><?php echo esc_html(get_theme_mod('help_para', 'We are available 24/7 to assist you with any issue.')); ?></p>
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>
<div class="container category-slider owl-carousel my-5">
	<?php
	$cat_slider = new WP_Query(array(
		'post_type' => 'categoryslider',
		'post_status' => 'publish',
		'post_per_page' => 3
	));
	if ($cat_slider->have_posts()) {
	?>
		<?php
		while ($cat_slider->have_posts()) {
			$cat_slider->the_post();
		?><div class="slider">
				<div class="row">
					<div class="col-12 col-md-8 slider-left">
						<div class="slider-heading">
							<h3>
								<?php the_field('eshop_slider_heading') ?></h3>
							<a href="<?php the_field('eshop_slider_more_link') ?>"> More <i class="fa-solid fa-arrow-right-long"></i></a>
						</div>
						<div class="icon-boxes col">
							<div class="icon-box">
								<?php
								$icon_box_1 = get_field('eshop_icon_box_1');
								$icon_1_image = $icon_box_1['icon']['sizes']['thumbnail'];
								?>
								<?php if ($icon_box_1) { ?>
									<a href="<?php echo $icon_box_1['link'] ?>">
										<img src="<?php echo $icon_1_image ?>" alt="" srcset="" style="width:50px !important;">
										<h4><?php echo $icon_box_1['title'] ?></h4>
									</a>
								<?php } ?>
							</div>
							<div class="icon-box">
								<?php
								$icon_box_2 = get_field('eshop_icon_box_2');
								$icon_2_image = $icon_box_2['icon']['sizes']['thumbnail'];
								?>
								<?php if ($icon_box_1) { ?>
									<a href="<?php echo $icon_box_2['link'] ?>">
										<img src="<?php echo $icon_2_image ?>" alt="" srcset="" style="width:50px !important;">
										<h4><?php echo $icon_box_2['title'] ?></h4>
									</a>
								<?php } ?>
							</div>
							<div class="icon-box">
								<?php
								$icon_box_3 = get_field('eshop_icon_box_3');
								$icon_1_image = $icon_box_1['icon']['sizes']['thumbnail'];
								?>
								<?php if ($icon_box_3) { ?>
									<a href="<?php echo $icon_box_3['link'] ?>">
										<img src="<?php echo $icon_1_image ?>" alt="" srcset="" style="width:50px !important;">
										<h4><?php echo $icon_box_3['title'] ?></h4>
									</a>
								<?php } ?>
							</div>
						</div>
						<div class="icon-boxes col">
							<div class="icon-box">
								<?php
								$icon_box_4 = get_field('eshop_icon_box_4');
								$icon_1_image = $icon_box_1['icon']['sizes']['thumbnail'];
								?>
								<?php if ($icon_box_4) { ?>
									<a href="<?php echo $icon_box_4['link'] ?>">
										<img src="<?php echo $icon_1_image ?>" alt="" srcset="" style="width:50px !important;">
										<h4><?php echo $icon_box_4['title'] ?></h4>
									</a>
								<?php } ?>
							</div>
							<div class="icon-box">
								<?php
								$icon_box_5 = get_field('eshop_icon_box_5');
								$icon_1_image = $icon_box_1['icon']['sizes']['thumbnail'];
								?>
								<?php if ($icon_box_5) { ?>
									<a href="<?php echo $icon_box_5['link'] ?>">
										<img src="<?php echo $icon_1_image ?>" alt="" srcset="" style="width:50px !important;">
										<h4><?php echo $icon_box_5['title'] ?></h4>
									</a>
								<?php } ?>
							</div>
							<div class="icon-box">
								<?php
								$icon_box_6 = get_field('eshop_icon_box_6');
								$icon_6_image = $icon_box_6['icon']['sizes']['thumbnail'];
								?>
								<?php if ($icon_box_6) { ?>
									<a href="<?php echo $icon_box_6['link'] ?>">
										<img src="<?php echo $icon_6_image ?>" alt="" srcset="" style="width:50px !important;">
										<h4><?php echo $icon_box_6['title'] ?></h4>
									</a>
								<?php } ?>
							</div>
						</div>
					</div>
					<div class="col-12 col-md-4 slider-img">
						<?php the_post_thumbnail('full') ?>
					</div>
				</div>
			</div>
		<?php }
		?>
	<?php
	} else {
		esc_html_e('Sorry, no posts matched your criteria.');
	}
	wp_reset_postdata();
	?>
</div>

<div class="woo-products container my-5">
	<div class="row ">
		<h3>New Arrivals</h3>
		<?php
		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => 4,
		);

		$products = new WP_Query($args);

		if ($products->have_posts()) :
			echo '<div class="product-grid">';

			while ($products->have_posts()) : $products->the_post();

				echo '<div class="product-column">';
				wc_get_template_part('content', 'product');
				echo '</div>';

			endwhile;

			echo '</div>';
			wp_reset_postdata();
		else :
			echo 'No products found';
		endif;
		?>

	</div>
</div>

<div class="container home-brands">
	<div class="row">
		<div class="brand-headings">
			<h2>
				Shop By Brands
			</h2>
			<a href="http://localhost/eshop/index.php/brand"> More <i class="fa-solid fa-arrow-right-long"></i></a>
		</div>
		<div class="brands-list">
			<?php
			$eshop_brand = new WP_Query(array(
				'post_type' => 'brand',
				'post_status' => 'publish',
				'post_per_page' => 6,
			));
			if ($eshop_brand->have_posts()) :
				while ($eshop_brand->have_posts()) {
					$eshop_brand->the_post();
					$brand_image = get_field('brand_image');
					$brand_url = get_field('brand_url');
					if ($brand_image) :
			?>
						<div class="brand">
							<a href="<?php echo esc_url($brand_url); ?>">
								<img src="<?php echo esc_url($brand_image['url']); ?>" alt="<?php echo esc_attr($brand_image['alt']); ?>">
							</a>
						</div>
			<?php
					endif;
				}
				wp_reset_postdata();
			endif;
			?>
		</div>
	</div>
</div>


<?php
get_footer();
