<?php

/**
 * eShop Monster Theme Customizer
 *
 * @package eShop_Monster
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */
function eshop_monster_customize_register($wp_customize)
{
	$wp_customize->get_setting('blogname')->transport         = 'postMessage';
	$wp_customize->get_setting('blogdescription')->transport  = 'postMessage';
	$wp_customize->get_setting('header_textcolor')->transport = 'postMessage';

	if (isset($wp_customize->selective_refresh)) {
		$wp_customize->selective_refresh->add_partial(
			'blogname',
			array(
				'selector'        => '.site-title a',
				'render_callback' => 'eshop_monster_customize_partial_blogname',
			)
		);
		$wp_customize->selective_refresh->add_partial(
			'blogdescription',
			array(
				'selector'        => '.site-description',
				'render_callback' => 'eshop_monster_customize_partial_blogdescription',
			)
		);
	}
	$wp_customize->add_section('custom_theme_copyright', array(
		'title' => __('Copyright', 'solar'),
		'priority' => 105,
	));

	$wp_customize->add_setting('custom_copyright_text', array(
		'default' => '',
		'sanitize_callback' => 'sanitize_text_field',
	));

	$wp_customize->add_control('custom_copyright_text', array(
		'label' => __('Copyright Text', 'solar'),
		'section' => 'custom_theme_copyright',
		'type' => 'text',
	));
}
add_action('customize_register', 'eshop_monster_customize_register');

/**
 * Render the site title for the selective refresh partial.
 *
 * @return void
 */
function eshop_monster_customize_partial_blogname()
{
	bloginfo('name');
}

/**
 * Render the site tagline for the selective refresh partial.
 *
 * @return void
 */
function eshop_monster_customize_partial_blogdescription()
{
	bloginfo('description');
}

/**
 * Binds JS handlers to make Theme Customizer preview reload changes asynchronously.
 */
function eshop_monster_customize_preview_js()
{
	wp_enqueue_script('eshop-monster-customizer', get_template_directory_uri() . '/js/customizer.js', array('customize-preview'), _S_VERSION, true);
}
add_action('customize_preview_init', 'eshop_monster_customize_preview_js');

// MY Customizations //

function eshop_shop_monster_customizer()
{
	new \Kirki\Panel(
		'header_settings',
		[
			'title'       => esc_html__('Header Settings', 'kirki'),
			'description' => esc_html__('You can easily manage all the settings of Header form here', 'kirki'),
			'priority'    => 10,
		]
	);

	new \Kirki\Section(
		'social_icons',
		[
			'title'    => esc_html__('Manage Social Icons'),
			'panel'    => 'header_settings',
			'priority' => 10,
		]
	);
	new \Kirki\Field\Checkbox_Switch(
		[
			'settings'    => 'switch_social',
			'label'       => esc_html__('Enable/Disable Icons', 'kirki'),
			'section'     => 'social_icons',
			'default'     => 'on',
			'choices'     => [
				'on'  => esc_html__('Enable', 'kirki'),
				'off' => esc_html__('Disable', 'kirki'),
			],
		]
	);
	new \Kirki\Field\URL(
		[
			'settings'  => 'url_setting_fb',
			'label'     => esc_html__('Social Icon URL 1', 'kirki'),
			'section'   => 'social_icons',
			'default'   => 'https://facebook.com/',
			'priority'  => 10,
		]
	);
	new \Kirki\Field\URL(
		[
			'settings'  => 'url_setting_in',
			'label'     => esc_html__('Social Icon URL 2', 'kirki'),
			'section'   => 'social_icons',
			'default'   => 'https://instagram.com/',
			'priority'  => 20,
		]
	);
	new \Kirki\Field\URL(
		[
			'settings'  => 'url_setting_li',
			'label'     => esc_html__('Social Icon URL 3', 'kirki'),
			'section'   => 'social_icons',
			'default'   => 'https://linkedin.com/',
			'priority'  => 30,
		]
	);
	new \Kirki\Field\URL(
		[
			'settings'  => 'url_setting_x',
			'label'     => esc_html__('X-Twitter URL', 'kirki'),
			'section'   => 'social_icons',
			'default'   => 'https://x.com/',
			'priority'  => 40,
		]
	);
	new \Kirki\Section(
		'woo_links',
		[
			'title'    => esc_html__('Manage WooCommerce Links'),
			'panel'    => 'header_settings',
			'priority' => 20,
		]
	);
	new \Kirki\Field\URL(
		[
			'settings'  => 'wishlist_url',
			'label'     => esc_html__('Wishlist URL', 'kirki'),
			'section'   => 'woo_links',
			'default'   => 'https://yourdomin.com/wishlist',
			'priority'  => 10,
		]
	);
	new \Kirki\Field\URL(
		[
			'settings'  => 'cart_url',
			'label'     => esc_html__('Cart URL', 'kirki'),
			'section'   => 'woo_links',
			'default'   => 'https://yourdomin.com/cart',
			'priority'  => 10,
		]
	);
	new \Kirki\Field\URL(
		[
			'settings'  => 'user_url',
			'label'     => esc_html__('My Account URL', 'kirki'),
			'section'   => 'woo_links',
			'default'   => 'https://yourdomin.com/my-account',
			'priority'  => 10,
		]
	);
	new \Kirki\Panel(
		'hero_settings',
		[
			'title'       => esc_html__('Hero Settings', 'kirki'),
			'description' => esc_html__('You can easily manage all the settings of Hero Section form here', 'kirki'),
			'priority'    => 20,
		]
	);
	new \Kirki\Section(
		'manage_hero',
		[
			'title'    => esc_html__('Manage Hero Sections'),
			'panel'    => 'hero_settings',
			'priority' => 10,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'hero_heading',
			'label'    => esc_html__('Hero Heading', 'kirki'),
			'section'  => 'manage_hero',
			'default'  => esc_html__('Imagine the Fashion Adventures.', 'kirki'),
			'priority' => 10,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'hero_para',
			'label'    => esc_html__('Hero Paragraph', 'kirki'),
			'section'  => 'manage_hero',
			'default'  => esc_html__('Embark on a sartorial odyssey through time and style, exploring the evolution of fashion across cultures, trends, and innovations in The Fashion Adventures', 'kirki'),
			'priority' => 20,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'hero_button_1',
			'label'    => esc_html__('Button 1 Label', 'kirki'),
			'section'  => 'manage_hero',
			'default'  => esc_html__('Men', 'kirki'),
			'priority' => 30,
		]
	);
	new \Kirki\Field\URL(
		[
			'settings'  => 'button_1_url',
			'label'     => esc_html__('Button 1 Link', 'kirki'),
			'section'   => 'manage_hero',
			'default'   => 'http://localhost/eshop/index.php/product-category/men/',
			'priority'  => 40,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'hero_button_2',
			'label'    => esc_html__('Button 2 Label', 'kirki'),
			'section'  => 'manage_hero',
			'default'  => esc_html__('Women', 'kirki'),
			'priority' => 50,
		]
	);
	new \Kirki\Field\URL(
		[
			'settings'  => 'button_2_url',
			'label'     => esc_html__('Button 2 Link', 'kirki'),
			'section'   => 'manage_hero',
			'default'   => 'http://localhost/eshop/index.php/product-category/women/',
			'priority'  => 60,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'hero_button_3',
			'label'    => esc_html__('Button 3 Label', 'kirki'),
			'section'  => 'manage_hero',
			'default'  => esc_html__('Kids', 'kirki'),
			'priority' => 70,
		]
	);
	new \Kirki\Field\URL(
		[
			'settings'  => 'button_3_url',
			'label'     => esc_html__('Button 3 Link', 'kirki'),
			'section'   => 'manage_hero',
			'default'   => 'http://localhost/eshop/index.php/product-category/kids/',
			'priority'  => 80,
		]
	);
	new \Kirki\Section(
		'manage_hero_images',
		[
			'title'    => esc_html__('Manage Hero Hero Images'),
			'panel'    => 'hero_settings',
			'priority' => 10,
		]
	);
	new \Kirki\Field\Image(
		[
			'settings'    => 'bg-image_setting_url',
			'label'       => esc_html__('Background Image', 'kirki'),
			'description' => esc_html__('The saved value will be the URL.', 'kirki'),
			'section'     => 'manage_hero_images',
			'default'     => '',
		]
	);
	new \Kirki\Field\Repeater(
		'image_repeater_field',
		[
			'label'    => esc_html__('Add Hero Images', 'kirki'),
			'section'  => 'manage_hero_images',
			'row_label' => [
				'type'  => 'text',
				'value' => esc_html__('Image', 'kirki'),
			],
			'button_label' => esc_html__('Add New Image', 'kirki'),
			'settings'     => 'image_repeater_setting',
			'default'      => [
				[
					'image_url' => '',
				],
			],
			'fields' => [
				'image_url' => [
					'type'        => 'image',
					'label'       => esc_html__('Image', 'kirki'),
					'description' => esc_html__('Select an image', 'kirki'),
				],
			],
		]
	);
	new \Kirki\Panel(
		'menu_settings',
		[
			'title'       => esc_html__('Mega Menu Headings', 'kirki'),
			'description' => esc_html__('You can easily manage all the Section Headings From Here', 'kirki'),
			'priority'    => 100,
		]
	);
	new \Kirki\Section(
		'manage_mega_headings',
		[
			'title'    => esc_html__('Add/Modify Menu Headings'),
			'panel'    => 'menu_settings',
			'priority' => 10,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'col_1',
			'label'    => esc_html__('Column 1 Heading', 'kirki'),
			'section'  => 'manage_mega_headings',
			'default'  => esc_html__('Men', 'kirki'),
			'priority' => 10,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'col_2',
			'label'    => esc_html__('Column 2 Heading', 'kirki'),
			'section'  => 'manage_mega_headings',
			'default'  => esc_html__('Kids', 'kirki'),
			'priority' => 20,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'col_3',
			'label'    => esc_html__('Column 3 Heading', 'kirki'),
			'section'  => 'manage_mega_headings',
			'default'  => esc_html__('Women', 'kirki'),
			'priority' => 30,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'col_4',
			'label'    => esc_html__('Column 4 Heading', 'kirki'),
			'section'  => 'manage_mega_headings',
			'default'  => esc_html__('Category', 'kirki'),
			'priority' => 40,
		]
	);
	new \Kirki\Panel(
		'hero_choose',
		[
			'title'       => esc_html__('Why Choose Us', 'kirki'),
			'description' => esc_html__('You can easily manage all the settings of Why Choose US Top Section form here', 'kirki'),
			'priority'    => 20,
		]
	);
	new \Kirki\Section(
		'manage_choose_headings',
		[
			'title'    => esc_html__('Add/Modify Choose Us Settings'),
			'panel'    => 'hero_choose',
			'priority' => 10,
		]
	);
	new \Kirki\Field\Checkbox_Switch(
		[
			'settings'    => 'switch_setting',
			'label'       => esc_html__('Enable or Disable Specialities', 'kirki'),
			'section'     => 'manage_choose_headings',
			'default'     => 'on',
			'choices'     => [
				'on'  => esc_html__('Enable', 'kirki'),
				'off' => esc_html__('Disable', 'kirki'),
			],
		]
	);
	new \Kirki\Field\Image(
		[
			'settings'    => 'global',
			'label'       => esc_html__('First Image Control (URL)', 'kirki'),
			'description' => esc_html__('The saved value will be the URL.', 'kirki'),
			'section'     => 'manage_choose_headings',
			'default'     => '',
			'priority' => 10,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'global_heading',
			'label'    => esc_html__('Column 1 Heading', 'kirki'),
			'section'  => 'manage_choose_headings',
			'default'  => esc_html__('Global Shipping', 'kirki'),
			'priority' => 20,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'global_para',
			'label'    => esc_html__('Column 1 Paragraph', 'kirki'),
			'section'  => 'manage_choose_headings',
			'default'  => esc_html__('Shop from anywhere in the world. We ship worldwide.', 'kirki'),
			'priority' => 30,
		]
	);
	new \Kirki\Field\Image(
		[
			'settings'    => 'safe',
			'label'       => esc_html__('Second Image Control (URL)', 'kirki'),
			'description' => esc_html__('The saved value will be the URL.', 'kirki'),
			'section'     => 'manage_choose_headings',
			'default'     => '',
			'priority' => 40,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'safe_heading',
			'label'    => esc_html__('Column 2 Heading', 'kirki'),
			'section'  => 'manage_choose_headings',
			'default'  => esc_html__('Safe Checkout', 'kirki'),
			'priority' => 50,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'safe_para',
			'label'    => esc_html__('Column 2 Paragraph', 'kirki'),
			'section'  => 'manage_choose_headings',
			'default'  => esc_html__('We protect our customer data at any cost.', 'kirki'),
			'priority' => 60,
		]
	);
	new \Kirki\Field\Image(
		[
			'settings'    => 'easy',
			'label'       => esc_html__('Third Image Control (URL)', 'kirki'),
			'description' => esc_html__('The saved value will be the URL.', 'kirki'),
			'section'     => 'manage_choose_headings',
			'default'     => '',
			'priority' => 70,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'easy_heading',
			'label'    => esc_html__('Column 3 Heading', 'kirki'),
			'section'  => 'manage_choose_headings',
			'default'  => esc_html__('Easy Returns', 'kirki'),
			'priority' => 80,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'easy_para',
			'label'    => esc_html__('Column 2 Paragraph', 'kirki'),
			'section'  => 'manage_choose_headings',
			'default'  => esc_html__('We have a free return& exchange policy.', 'kirki'),
			'priority' => 90,
		]
	);
	new \Kirki\Field\Image(
		[
			'settings'    => 'help',
			'label'       => esc_html__('Fourth Image Control (URL)', 'kirki'),
			'description' => esc_html__('The saved value will be the URL.', 'kirki'),
			'section'     => 'manage_choose_headings',
			'default'     => '',
			'priority' => 100,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'help_heading',
			'label'    => esc_html__('Column 4 Heading', 'kirki'),
			'section'  => 'manage_choose_headings',
			'default'  => esc_html__('Help & Support', 'kirki'),
			'priority' => 110,
		]
	);
	new \Kirki\Field\Text(
		[
			'settings' => 'help_para',
			'label'    => esc_html__('Column 4 Paragraph', 'kirki'),
			'section'  => 'manage_choose_headings',
			'default'  => esc_html__('We are available 24/7 to assist you with any issue.', 'kirki'),
			'priority' => 120,
		]
	);
	new \Kirki\Panel(
		'color_scheme',
		[
			'title'       => esc_html__('General Colors', 'kirki'),
			'description' => esc_html__('You can easily manage all the Theme Colors', 'kirki'),
			'priority'    => 30,
		]
	);
	new \Kirki\Section(
		'general',
		[
			'title'    => esc_html__('General'),
			'panel'    => 'color_scheme',
			'priority' => 10,
		]
	);
	new \Kirki\Field\Color(
		[
			'settings'    => 'color_primiary_setting_hex',
			'label'       => __('Primary Color (hex only)', 'kirki'),
			'description' => esc_html__('Regular Primary Color, no alpha channel.', 'kirki'),
			'section'     => 'general',
			'default'     => '#1F2642',
			'transport' => 'auto',
			'output' => array(
				array(
					'element'  => array(
						'.main-header',
						'.why-choose-us',
					),
					'property' => 'background-color',
					'suffix' => '!important',
				),
			),
		]
	);
	new \Kirki\Field\Color(
		[
			'settings'    => 'color_secondary_setting_hex',
			'label'       => __('Secondary Color (hex only)', 'kirki'),
			'description' => esc_html__('Regular Secondary Color, no alpha channel.', 'kirki'),
			'section'     => 'general',
			'default'     => '#FE6E0E',
			'transport' => 'auto',
			'output' => array(
				array(
					'element'  => array(
						'.top-header',
						'.site-branding .hum i ',
					),
					'property' => 'background-color',
				),
			),
		]
	);
	new \Kirki\Field\Color(
		[
			'settings'    => 'color_text_setting_hex',
			'label'       => __(' Color (hex only)', 'kirki'),
			'description' => esc_html__('Regular  Color, no alpha channel.', 'kirki'),
			'section'     => 'general',
			'default'     => '#000',
		]
	);
}

eshop_shop_monster_customizer();


function eshop_monster_footer_widget()
{
	register_sidebar(array(
		'name'          => __('Primary Sidebar', 'eshop-monster'),
		'id'            => 'sidebar-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h3 class="widget-title">',
		'after_title'   => '</h3>',
	));

	register_sidebar(array(
		'name'          => __('Footer Widget 1', 'eshop-monster'),
		'id'            => 'footer-1',
		'before_widget' => '<ul><li id="%1$s" class="footer-widget %2$s">',
		'after_widget'  => '</li></ul>',
		'before_title'  => '<h3 class="footer-widget-title">',
		'after_title'   => '</h3>',
	));
	register_sidebar(array(
		'name'          => __('Footer Widget 2', 'eshop-monster'),
		'id'            => 'footer-2',
		'before_widget' => '<ul><li id="%2$s" class="footer-widget %2$s">',
		'after_widget'  => '</li></ul>',
		'before_title'  => '<h3 class="footer-widget-title">',
		'after_title'   => '</h3>',
	));
	register_sidebar(array(
		'name'          => __('Footer Widget 3', 'eshop-monster'),
		'id'            => 'footer-3',
		'before_widget' => '<ul><li id="%3$s" class="footer-widget %2$s">',
		'after_widget'  => '</li></ul>',
		'before_title'  => '<h3 class="footer-widget-title">',
		'after_title'   => '</h3>',
	));
	register_sidebar(array(
		'name'          => __('Footer Widget 4', 'eshop-monster'),
		'id'            => 'footer-4',
		'before_widget' => '<ul><li id="%4W$s" class="footer-widget %2$s">',
		'after_widget'  => '</li></ul>',
		'before_title'  => '<h3 class="footer-widget-title">',
		'after_title'   => '</h3>',
	));
}

eshop_monster_footer_widget();
