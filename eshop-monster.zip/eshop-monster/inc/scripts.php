<?php
function eshop_monster_scripts()
{
    wp_enqueue_style('bootstrap-css', get_template_directory_uri() . '/assets/bs/css/bootstrap.min.css', array(), '5.3.2');

    wp_enqueue_style('font-awesome', get_template_directory_uri() . '/assets/fa/css/all.min.css', array(), '6.5.1');

    wp_enqueue_style('font-awesome-v4', get_template_directory_uri() . '/assets/fa/css/v4-shims.min.css', array(), '6.5.1');

    wp_enqueue_style('owl-carousel-css', get_template_directory_uri() . '/assets/owl/assets/owl.carousel.min.css', array(), '2.3.4');

    wp_enqueue_style('eshop-monster-style', get_stylesheet_uri(), array(), _S_VERSION);

    wp_enqueue_script('eshop-monster-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);

    wp_enqueue_script('jquery');

    wp_enqueue_script('bootstap-js', get_template_directory_uri() . '/assets/bs/js/bootstrap.min.js', array('jquery'), '5.3.2', false);

    wp_enqueue_script('owl-carousel-js', get_template_directory_uri() . '/assets/owl/owl.carousel.min.js', array(), '2.3.4', false);

    wp_enqueue_script('eshop-monster-custom-script', get_template_directory_uri() . '/assets/js/script.js', array('jquery'), '', true);


    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'eshop_monster_scripts');
