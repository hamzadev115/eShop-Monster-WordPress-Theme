<style>
    :root {
        --primary: <?php echo get_theme_mod('color_primiary_setting_hex', '#1F2642'); ?> --acent: <?php echo get_theme_mod('color_secondary_setting_hex', '#FE6E0E'); ?>;
        --silver: #F2F2F4;
        --text: <?php echo get_theme_mod('color_text_setting_hex', '#000'); ?>;
    }
</style>