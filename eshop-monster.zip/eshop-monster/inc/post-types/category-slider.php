<?php
// Register Custom Post Type Category Slider
function create_categoryslider_cpt()
{

    $labels = array(
        'name' => _x('Category Sliders', 'Post Type General Name', 'eshop-monster'),
        'singular_name' => _x('Category Slider', 'Post Type Singular Name', 'eshop-monster'),
        'menu_name' => _x('Category Sliders', 'Admin Menu text', 'eshop-monster'),
        'name_admin_bar' => _x('Category Slider', 'Add New on Toolbar', 'eshop-monster'),
        'archives' => __('Category Slider Archives', 'eshop-monster'),
        'attributes' => __('Category Slider Attributes', 'eshop-monster'),
        'parent_item_colon' => __('Parent Category Slider:', 'eshop-monster'),
        'all_items' => __('All Category Sliders', 'eshop-monster'),
        'add_new_item' => __('Add New Category Slider', 'eshop-monster'),
        'add_new' => __('Add New', 'eshop-monster'),
        'new_item' => __('New Category Slider', 'eshop-monster'),
        'edit_item' => __('Edit Category Slider', 'eshop-monster'),
        'update_item' => __('Update Category Slider', 'eshop-monster'),
        'view_item' => __('View Category Slider', 'eshop-monster'),
        'view_items' => __('View Category Sliders', 'eshop-monster'),
        'search_items' => __('Search Category Slider', 'eshop-monster'),
        'not_found' => __('Not found', 'eshop-monster'),
        'not_found_in_trash' => __('Not found in Trash', 'eshop-monster'),
        'featured_image' => __('Featured Image', 'eshop-monster'),
        'set_featured_image' => __('Set featured image', 'eshop-monster'),
        'remove_featured_image' => __('Remove featured image', 'eshop-monster'),
        'use_featured_image' => __('Use as featured image', 'eshop-monster'),
        'insert_into_item' => __('Insert into Category Slider', 'eshop-monster'),
        'uploaded_to_this_item' => __('Uploaded to this Category Slider', 'eshop-monster'),
        'items_list' => __('Category Sliders list', 'eshop-monster'),
        'items_list_navigation' => __('Category Sliders list navigation', 'eshop-monster'),
        'filter_items_list' => __('Filter Category Sliders list', 'eshop-monster'),
    );
    $args = array(
        'label' => __('Category Slider', 'eshop-monster'),
        'description' => __('Category Slider for Hero Section', 'eshop-monster'),
        'labels' => $labels,
        'menu_icon' => 'dashicons-slides',
        'supports' => array('title', 'thumbnail', 'revisions', 'author'),
        'taxonomies' => array(),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => true,
        'can_export' => true,
        'has_archive' => false,
        'hierarchical' => false,
        'exclude_from_search' => true,
        'show_in_rest' => false,
        'publicly_queryable' => true,
        'capability_type' => 'post',
    );
    register_post_type('categoryslider', $args);
}
add_action('init', 'create_categoryslider_cpt', 0);
