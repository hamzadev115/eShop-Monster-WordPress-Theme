<div class="desktop-header">
    <div class="container mt-3">
        <div class="row top-header">
            <div class="col-12 col-md-8">
                <?php wp_nav_menu(
                    array(
                        'menu' => 'top-menu',
                        'menu_class' => 'top-menu',
                    )
                ) ?>
            </div>
            <div class="col-12 col-md-4">
                <?php if (true == get_theme_mod('switch_social', 'on')) : ?>
                    <div class="social-icons">
                        <a href="<?php echo get_theme_mod('url_setting_fb') ?>" target="_blank"><i class="fa-brands fa-facebook"></i></a>
                        <a href="<?php echo get_theme_mod('url_setting_in') ?>" target="_blank"><i class="fa-brands fa-instagram"></i></a>
                        <a href="<?php echo get_theme_mod('url_setting_li') ?>" target="_blank"><i class="fa-brands fa-linkedin"></i></a>
                        <a href="<?php echo get_theme_mod('url_setting_x') ?>" target="_blank"><i class="fa-brands fa-x-twitter"></i></a>
                    </div>
                <?php endif ?>
            </div>
        </div>
    </div>

    <div class="container main-header">
        <div class="row align-items-center">
            <div class="site-branding col-md-3">
                <div class="hum">
                    <i class="fa-solid fa-bars"></i>
                </div>
                <div class="logo">
                    <?php
                    if (has_custom_logo()) {
                        the_custom_logo();
                    } else {

                        bloginfo('name');
                    }
                    ?>
                </div>
            </div>
            <div class="header-search col-md-6">
                <div class="search-group input-group mb-3">
                    <input type="text" class="form-control" aria-label="Text input with dropdown button" placeholder="Search...">
                    <select name="product_categories" id="product-cat">
                        <option value="0">All Categories</option>
                        <?php
                        $product_categories = get_terms(array(
                            'taxonomy' => 'product_cat',
                            'parent' => 0,
                            'hide_empty' => false,
                        ));
                        foreach ($product_categories as $category) {
                            $category_link = get_term_link($category);
                            echo '<option value="' . $category_link . '">' . $category->name . '</option>';

                            $child_categories = get_terms(array(
                                'taxonomy' => 'product_cat',
                                'parent' => $category->term_id,
                                'hide_empty' => false,
                            ));
                            foreach ($child_categories as $child_category) {
                                $child_category_link = get_term_link($child_category);

                                echo '<option value="' . $child_category_link . '">&nbsp;&nbsp;' . $child_category->name . '</option>';
                            }
                        }
                        ?>
                    </select>
                    <button type="submit" class="submitbtn"><i class="fa-solid fa-magnifying-glass"></i></button>
                </div>
            </div>
            <div class="header-icons col-md-3">
                <div class="icon-list"> <a href="<?php get_theme_mod('wishlist_url') ?>"><i class="fa-regular fa-heart"></i></a></div>
                <div class="icon-list"><a href="<?php get_theme_mod('cart_url') ?>"><i class="fa-regular fa-user"></i></a></div>
                <div class="icon-list"><a href="<?php get_theme_mod('user_url') ?>"><i class="fa-solid fa-bag-shopping"></i></a></div>
            </div>
        </div>
    </div>
    <div class="container menu-list">
        <div class="row">
            <div class="col-12 col-md-6 col-lg-3 menu-mega-list">
                <h2>
                    <?php echo esc_html(get_theme_mod('col_1', 'Men')); ?>
                </h2>
                <?php wp_nav_menu(
                    array(
                        'theme_location' => 'mega-menu-1'
                    )
                ) ?>
            </div>
            <div class="col-12 col-md-6 col-lg-3  menu-mega-list">
                <h2>
                    <?php echo esc_html(get_theme_mod('col_2', 'Kids')); ?>
                </h2>
                <?php wp_nav_menu(
                    array(
                        'theme_location' => 'mega-menu-2'
                    )
                ) ?>
            </div>
            <div class="col-12 col-md-6 col-lg-3 menu-mega-list">
                <h2>
                    <?php echo esc_html(get_theme_mod('col_3', 'Women')); ?>
                </h2>
                <?php wp_nav_menu(
                    array(
                        'theme_location' => 'mega-menu-3'
                    )
                ) ?>
            </div>
            <div class="col-12 col-md-6 col-lg-3  menu-mega-list">
                <h2>
                    <?php echo esc_html(get_theme_mod('col_4', 'Category')); ?>
                </h2>
                <?php wp_nav_menu(
                    array(
                        'theme_location' => 'mega-menu-4'
                    )
                ) ?>
            </div>
        </div>
    </div>
</div>