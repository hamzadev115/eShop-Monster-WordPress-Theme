<?php

/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package eShop_Monster
 */

?>
</div>
<div class="container  footer">
	<div class="row">
		<div class="col-12 col-md-3 site-links">
			<h2>Customer Care</h2>
			<a href=""><i class="fa-solid fa-arrow-right-long"></i> Cookies Policy</a>
			<a href=""><i class="fa-solid fa-arrow-right-long"></i> Returns Policy</a>
			<a href=""><i class="fa-solid fa-arrow-right-long"></i> Delivery Policy</a>
			<a href=""><i class="fa-solid fa-arrow-right-long"></i> Customer Center</a>
		</div>
		<div class="col-12 col-md-3 site-links">
			<h2>Site Links</h2>
			<a href=""><i class="fa-solid fa-arrow-right-long"></i> My Account</a>
			<a href=""><i class="fa-solid fa-arrow-right-long"></i> Privacy Policy</a>
			<a href=""><i class="fa-solid fa-arrow-right-long"></i> Terms & Conditions</a>
			<a href=""><i class="fa-solid fa-arrow-right-long"></i> Refund & Returns</a>
		</div>
		<div class="col-12 col-md-3 shop-links">
			<h2>Shop</h2>
			<a href=""><i class="fa-solid fa-arrow-right-long"></i> Men</a>
			<a href=""><i class="fa-solid fa-arrow-right-long"></i> Women</a>
			<a href=""><i class="fa-solid fa-arrow-right-long"></i> Kids</a>
			<a href=""><i class="fa-solid fa-arrow-right-long"></i> Accessories</a>
		</div>
		<div class="col-12 col-md-3 payments">
			<h2>Payments</h2>
			<div class="payment-icons">
				<i class="fa-regular fa-credit-card">
					<h4>Credit/Debit Card</h4>
				</i>
				<i class="fa-brands fa-paypal">
					<h4> Paypal </h4>
				</i>
				<i class="fa-solid fa-money-bill-transfer">
					<h4>Bank Transfer </h4>
				</i>
				<i class="fa-regular fa-handshake">
					<h4> Cash on Delivery </h4>
				</i>
			</div>
		</div>
	</div>
</div>
<div class="conatiner sub-footer mb-4">
	<div class="row">
		<div class="col col-md-6">
			<?php
			wp_nav_menu(
				array(
					'menu' => 'footer-menu'
				)
			);
			?>
		</div>
		<div class="col col-md-6">
			<?php
			$copyright_text = get_theme_mod('custom_copyright_text');
			$current_year = date('Y');
			if ($copyright_text) {
				echo '<div class="copyright">' . ' &copy;' . esc_html($current_year) . ' ' . esc_html($copyright_text) . '</div>';
			}
			?>
		</div>
	</div>
</div>


<?php wp_footer(); ?>
</div>
</body>

</html>